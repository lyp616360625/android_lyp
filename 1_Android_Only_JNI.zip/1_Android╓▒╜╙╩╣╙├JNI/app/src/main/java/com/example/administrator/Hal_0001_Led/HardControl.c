#include <stdio.h>
#include <jni.h>
#include <android/log.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>


int fd;

jint  JNICALL ledOpen(JNIEnv *env, jobject cls)
{
	fd = open("/dev/leds", 2);
	return 0;
}


jint  JNICALL ledControl(JNIEnv *env, jobject cls, jint which, jint status)
{
	ioctl(fd, status, which);
	return 0;
}



void  JNICALL ledClose(JNIEnv *env, jobject cls)
{	
	close(fd);
}



static const JNINativeMethod methods[] = {
	{"ledControl", "(II)I", (void *)ledControl},
	{"ledOpen", "()I", (void *)ledOpen},
	{"ledClose", "()V", (void *)ledClose},

};

JNIEXPORT jint JNICALL  //lyp:It must used  next to JNI_OnLoad(JavaVM *jvm, void *reserved)
JNI_OnLoad(JavaVM *jvm, void *reserved)
{
	JNIEnv *env;
	jclass cls;
	if ((*jvm)->GetEnv(jvm, (void **)&env, JNI_VERSION_1_4)) {
		return JNI_ERR; //lyp:1.set the jni version
	}
	cls = (*env)->FindClass(env, "com/example/administrator/hardlibrary/HardControl");//lyp:2.set the class have used in java
	if (cls == NULL) {
		return JNI_ERR;
	}
	

	if((*env)->RegisterNatives(env, cls, methods, sizeof(methods)/sizeof(methods[0]))<0)//lyp:regesiter function(env,cls,method,num)
		return 	JNI_ERR;
	return JNI_VERSION_1_4;
}




