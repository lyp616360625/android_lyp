package com.example.administrator.app_0001_led;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import com.example.administrator.hardlibrary.*;

public class MainActivity extends AppCompatActivity {
    Button button = null;

    boolean buttonFlag = false;

    CheckBox LED1 = null;
    CheckBox LED2 = null;
    CheckBox LED3 = null;
    CheckBox LED4 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        HardControl.ledOpen();

        button = (Button) findViewById(R.id.Button1);
        LED1 = (CheckBox) findViewById(R.id.LED1);
        LED2 = (CheckBox) findViewById(R.id.LED2);
        LED3 = (CheckBox) findViewById(R.id.LED3);
        LED4 = (CheckBox) findViewById(R.id.LED4);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                buttonFlag = !buttonFlag;
                if(buttonFlag){
                    button.setText("ALL LED OFF");
                    LED1.setChecked(true);
                    LED2.setChecked(true);
                    LED3.setChecked(true);
                    LED4.setChecked(true);
                    for(int i=0; i<4; i++)
                    HardControl.ledControl(i,1);

                }

                else{
                    button.setText("ALL LED ON");
                    LED1.setChecked(false);
                    LED2.setChecked(false);
                    LED3.setChecked(false);
                    LED4.setChecked(false);
                    for(int i=0; i<4; i++)
                        HardControl.ledControl(i,0);

                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.LED1:
                if (checked){
                    Toast.makeText(getApplicationContext(), "LED1 ON",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(0,1);
                }

                else{
                    Toast.makeText(getApplicationContext(), "LED1 OFF",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(0,0);
                }

                break;
            case R.id.LED2:
                if (checked){
                    Toast.makeText(getApplicationContext(), "LED2 ON",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(1, 1);
                }

                else{
                    Toast.makeText(getApplicationContext(), "LED2 OFF",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(1, 0);
                }

                break;
            case R.id.LED3:
                if (checked){
                    Toast.makeText(getApplicationContext(), "LED3 ON",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(2, 1);
                }

                else{
                    Toast.makeText(getApplicationContext(), "LED3 OFF",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(2, 0);
                }

                break;
            case R.id.LED4:
                if (checked){
                    Toast.makeText(getApplicationContext(), "LED4 ON",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(3, 1);
                }

                else{
                    Toast.makeText(getApplicationContext(), "LED4 OFF",
                            Toast.LENGTH_SHORT).show();
                    HardControl.ledControl(3, 0);
                }

                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
