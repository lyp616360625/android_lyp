package com.android.server;

import android.os.ILedService;

public class LedService extends ILedService.Stub{
    private static final String TAG = "LedService";

	
	public int ledcontrol(int which, int status) throws android.os.RemoteException{
		return native_ledControl(which, status);
	}

	public LedService(){
		native_ledOpen();
	}
	public native int native_ledOpen();
	public native void native_ledClose();
	public native int native_ledControl(int which, int status);
	
}


