#define LOG_TAG "LedService"

#include "jni.h"
#include "JNIHelp.h"


#include <utils/misc.h>
#include <utils/Log.h>
#include <hardware_legacy/vibrator.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>





namespace android
{

int fd;

jint  JNICALL ledOpen(JNIEnv *env, jobject cls)
{
	fd = open("/dev/leds", 2);
	ALOGI("ledOpen\n");
	return 0;
}


jint  JNICALL ledControl(JNIEnv *env, jobject cls, jint which, jint status)
{
	ioctl(fd, status, which);
	ALOGI("ledControl! fd=%d, status=%d,The led is %d\n", fd,status,which);
	return 0;
}



void  JNICALL ledClose(JNIEnv *env, jobject cls)
{	
	ALOGI("ledClose\n");

	close(fd);
}



static const JNINativeMethod method_table[] = {
	{"native_ledControl", "(II)I", (void *)ledControl},
	{"native_ledOpen", "()I", (void *)ledOpen},
	{"native_ledClose", "()V", (void *)ledClose},

};


int register_android_server_LedService(JNIEnv *env)
{
    return jniRegisterNativeMethods(env, "com/android/server/LedService",
            method_table, NELEM(method_table));
}

};

