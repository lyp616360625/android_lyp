#define LOG_TAG "ledhal"


/*1.ʵ��һ����ΪHMI��hw_module_t�ṹ��*/
/*2.ʵ��һ��open����������һ���豸�Զ���Ľṹ��*/
#include <hardware/vibrator.h>
#include <hardware/hardware.h>

#include <cutils/log.h>
#include <utils/Log.h>

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <hardware/ledhal.h>

#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>




static int fd;

static int ledclose(struct hw_device_t* device)
{
	
	ALOGI("ledclose\n");
	close(fd);
	return 0;
}

static int ledopen(struct led_device_t* dev)
{
	
	fd = open("/dev/leds", 2);
	ALOGI("ledopen\n");
	return 0;
	
}



static int ledcontrol(struct led_device_t* dev, int which, int status)
{	
	ioctl(fd, status, which);
	ALOGI("ledcontrol! fd=%d, status=%d,The led is %d\n", fd,status,which);
	return 0;
}



struct led_device_t led_dev = {
	.common = {
		.close = ledclose,
	},
	.ledopen = ledopen,
	.ledcontrol = ledcontrol,
	
};


static int led_device_open(const struct hw_module_t* module, const char* id,
		   struct hw_device_t** device)
{
	*device = &led_dev;
	return 0;
}



static struct hw_module_methods_t led_module_methods = {
    .open = led_device_open,
};

struct hw_module_t HAL_MODULE_INFO_SYM = {
	.tag = HARDWARE_MODULE_TAG,
    .id 	 = "led",
    .methods = &led_module_methods,
};


