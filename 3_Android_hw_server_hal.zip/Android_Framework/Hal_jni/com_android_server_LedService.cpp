#define LOG_TAG "LedService"

#include "jni.h"
#include "JNIHelp.h"


#include <utils/misc.h>
#include <utils/Log.h>
#include <hardware_legacy/vibrator.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <hardware/ledhal.h>

namespace android
{

led_device_t* led_device;


jint  JNICALL ledOpen(JNIEnv *env, jobject cls)
{
	int err;
	hw_module_t* module;
	hw_device_t* device;
	
	
	
	ALOGI("nativeledOpen\n");
	/*1.hw_get_modules*/
    err = hw_get_module("led", (hw_module_t const**)&module);



	/*2.module->methods->open(module, NULL, &device);*/
    err = module->methods->open(module, NULL, &device);

	if (err == 0) {
		/*3.call ledopen*/
        led_device = (led_device_t*)device;
		return led_device->ledopen(led_device);
    } else {
        return -1;
    }
	
	return -1;
}


jint  JNICALL ledControl(JNIEnv *env, jobject cls, jint which, jint status)
{
	
	ALOGI("ledControl! status=%d,The led is %d\n", status, which);
	return led_device->ledcontrol(led_device, which, status);
}

 

void  JNICALL ledClose(JNIEnv *env, jobject cls)
{	

}



static const JNINativeMethod method_table[] = {
	{"native_ledControl", "(II)I", (void *)ledControl},
	{"native_ledOpen", "()I", (void *)ledOpen},
	{"native_ledClose", "()V", (void *)ledClose},

};


int register_android_server_LedService(JNIEnv *env)
{
    return jniRegisterNativeMethods(env, "com/android/server/LedService",
            method_table, NELEM(method_table));
}

};

