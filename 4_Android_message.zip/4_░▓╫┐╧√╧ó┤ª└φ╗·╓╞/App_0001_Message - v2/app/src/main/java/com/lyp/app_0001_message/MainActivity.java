package com.lyp.app_0001_message;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private Button mybutton;
    private final String Tag = "ButtonMessage";
    private int buttonCount = 0;
    private Thread mythread;
    private MyThread mythread2;
    class myRunnable implements Runnable{
        int count = 0;
        @Override
        public void run() {
            for(;;){
                Log.d(Tag, "HaHa!" + count);
                count++;
                try {
                    mythread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    class MyThread  extends Thread{
        @Override
        public void run() {
            int count = 0;

            super.run();
            for(;;){
                Log.d(Tag, "hehe!" + count);
                count++;
                try {
                    mythread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mybutton =(Button)findViewById(R.id.button);

        mybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(Tag, "OK! " + buttonCount);
                buttonCount++;

            }
        });

        mythread = new Thread(new myRunnable(), "MessageThread");
        mythread.start();

        mythread2 = new MyThread();
        mythread2.start();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
