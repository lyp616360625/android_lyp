package com.lyp.app_0001_message;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;
import android.util.Log;
import android.os.HandlerThread;



public class MainActivity extends AppCompatActivity {

    private Button mybutton;
    private final String Tag = "ButtonMessage";
    private int buttonCount = 0;
    private Thread mythread;
    private MyThread mythread2;
    private Handler myhandler;
    private Handler myhandler3;
    private int Messagecount;
    private HandlerThread mythread3;

    class myRunnable implements Runnable{
        int count = 0;
        @Override
        public void run() {
            for(;;){
                Log.d(Tag, "HaHa!" + count);
                count++;
                try {
                    mythread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    class MyThread  extends Thread{

        private Looper mlooper;
        @Override
        public void run() {
            super.run();
            Looper.prepare();
            synchronized (this){
                mlooper = Looper.myLooper();
                notifyAll();
            }

            Looper.loop();

        }

        public Looper getloop(){
            if(!isAlive()){
                return null;
            }

            synchronized (this){
                while (isAlive() && mlooper == null){
                    try{
                        wait();
                    }catch (InterruptedException e){
                    }
                }
            }


            return  Looper.myLooper();

        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mybutton =(Button)findViewById(R.id.button);

        mybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(Tag, "OK! " + buttonCount);
                buttonCount++;
                Message msg = new Message();
                myhandler.sendMessage(msg);

                myhandler3.post(new Runnable() {
                    @Override
                    public void run() {
                        Log.d(Tag, "Get Message3! " + Messagecount);
                        Messagecount++;
                    }
                });

            }
        });

        mythread = new Thread(new myRunnable(), "MessageThread");
        mythread.start();

        mythread2 = new MyThread();
        mythread2.start();

        myhandler = new Handler(mythread2.getloop(), new Handler.Callback(){
            @Override
            public boolean handleMessage(Message message) {
                Log.d(Tag, "Get Message! " + Messagecount);
                Messagecount++;
                return false;
            }
        });

        mythread3 = new HandlerThread("Messagethread3");
        mythread3.start();

        myhandler3 = new Handler(mythread3.getLooper());


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
